package com.example.projectv1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.HashMap;
import java.util.Map;

public class Login extends AppCompatActivity implements View.OnClickListener {


    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button loginButton;
    private SharedPreferences savedValues;

    private FirebaseAuth mAuth;
    static FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize Firebase Auth
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        // get the sharedpref
        savedValues = getSharedPreferences("SavedValues", MODE_PRIVATE);
        SharedPreferences.Editor editor = savedValues.edit();

        getSupportActionBar().setTitle("Home Maintenance App");

        // check if user already logged in and if so we skip the login
        if (savedValues.getString("email", "").length()>0) // means it exists and isnt empty
        {
            // Redirect to ProfilePage
            Intent intent = new Intent(Login.this, Home.class);
            startActivity(intent);
            //finish();  // Close the login activity after redirecting
        }

        // from here on it means the user wasnt already logged in
        usernameEditText = findViewById(R.id.username);
        passwordEditText = findViewById(R.id.password);
        loginButton = findViewById(R.id.btn_login);
    }

    @Override
    public void onClick(View view) {
        String username = usernameEditText.getText().toString();
        String password = passwordEditText.getText().toString();
        CollectionReference users = db.collection("Users");
        savedValues = getSharedPreferences("SavedValues", MODE_PRIVATE);
        SharedPreferences.Editor editor = savedValues.edit();

        if (password.isEmpty() || username.isEmpty()) {
            Toast.makeText(getApplicationContext(), "Missing field(s)",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        if (view.getId()==R.id.btn_login){
                     mAuth.signInWithEmailAndPassword(username,password)
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                // Sign in success, update UI with the signed-in user's information
                                FirebaseUser user = mAuth.getCurrentUser();

                                // we find if the user is worker or resident and then assign it in saved prefs
                                db.collection("Users")
                                        .whereEqualTo("email",username)
                                        .get()
                                        .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                            @Override
                                            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                                if (task.isSuccessful()) {
                                                    for (QueryDocumentSnapshot document : task.getResult()) {
                                                        editor.putBoolean("isResident", document.getBoolean("isResident"));
                                                        editor.putBoolean("isWorker", document.getBoolean("isWorker"));
                                                        editor.commit();
                                                    }
                                                }
                                            }
                                        });

                                Intent i = new Intent(Login.this, Home.class);
                                editor.putString("email", username); // to keep user logged in
                                editor.commit();
                                startActivity(i);
                            } else {
                                // If sign in fails, display a message to the user.
                                Toast.makeText(getApplicationContext(), "Incorrect email or password.",
                                        Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
        }
        else if (view.getId()==R.id.btn_signup){
            mAuth.createUserWithEmailAndPassword(username, password)
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                // adding the user to the collection of users to be able to know if theyre worker or resident in the future
                                Map<String, Object> newUser = new HashMap<>();
                                newUser.put("email", username);
                                newUser.put("isWorker", false);
                                newUser.put("isResident", true);
                                users.document(username).set(newUser);

                                // Sign in success, update UI with the signed-in user's information
                                Toast.makeText(getApplicationContext(), "Create User With Email : success\nPlease login",Toast.LENGTH_SHORT).show();
                                        FirebaseUser user = mAuth.getCurrentUser();
                            } else {
                                // If sign in fails, display a message to the user.
                                Toast.makeText(getApplicationContext(), "Creating user failed",
                                        Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
        }
    }
}