package com.example.projectv1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Home extends AppCompatActivity {

    private SharedPreferences savedValues;
    private TextView tv_name;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        if(savedValues.getBoolean("isResident",false)) {
            getMenuInflater().inflate(
                    R.menu.resident_menu, menu);
        }
        if(savedValues.getBoolean("isWorker",false)) {
            getMenuInflater().inflate(
                    R.menu.worker_menu, menu);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch (item.getItemId())
        {
            case R.id.menu_home:
                Toast.makeText(this, "Already in Home",
                        Toast.LENGTH_SHORT).show();
                return true;
            case R.id.menu_request_service:
                Intent intent2 = new Intent(Home.this, RequestService.class);
                startActivity(intent2);
                return true;
            case R.id.menu_requested_service:
                Intent intent3 = new Intent(Home.this, RequestedServices.class);
                startActivity(intent3);
                return true;
            case R.id.menu_completed_services:
                Intent intent1 = new Intent(Home.this, CompletedServices.class);
                startActivity(intent1);
                return true;
            case R.id.menu_accepted_services:
                Intent intent5 = new Intent(Home.this, AcceptedServices.class);
                startActivity(intent5);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // get SharedPreferences object
        savedValues = getSharedPreferences("SavedValues", MODE_PRIVATE);
        SharedPreferences.Editor editor = savedValues.edit();

        tv_name = findViewById(R.id.tv_name);
        tv_name.setText(savedValues.getString("email",""));

        getSupportActionBar().setTitle("Home");


        Button btn_requested_services = findViewById(R.id.btn_requested_services);
        btn_requested_services.setOnClickListener(v -> {
            Intent intent = new Intent(Home.this, RequestedServices.class);
            startActivity(intent);
        });

        Button btn_completed_services = findViewById(R.id.btn_completed_services);
        btn_completed_services.setOnClickListener(v -> {
            Intent intent = new Intent(Home.this, CompletedServices.class);
            startActivity(intent);
        });

        Button btn_request_service = findViewById(R.id.btn_request_service);
        if(savedValues.getBoolean("isWorker",false)) btn_request_service.setText("Accepted Services");
        btn_request_service.setOnClickListener(v -> {

            if(savedValues.getBoolean("isResident",false)) {
                Intent intent = new Intent(Home.this, RequestService.class);
                startActivity(intent);
            }
            if(savedValues.getBoolean("isWorker",false)) {
                Intent intent = new Intent(Home.this, AcceptedServices.class);
                startActivity(intent);
            }

        });


        // Initializing the logout button using its ID from your layout file
        Button btn_logout = findViewById(R.id.btn_logout);
        btn_logout.setOnClickListener(v -> {
            // delete info from savedprefs
            editor.putString("email", "");
            editor.putBoolean("isResident", true);
            editor.putBoolean("isWorker", false);
            editor.commit();

            // Create an Intent to start MainActivity when logout button is clicked
            Intent intent = new Intent(Home.this, Login.class);

            // Setting flags to clear the activity stack, which simulates a logout by clearing all previous activities
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);

            // Start MainActivity with the intent
            startActivity(intent);
            finish(); // Call this to finish the current activity
        });

    }
}