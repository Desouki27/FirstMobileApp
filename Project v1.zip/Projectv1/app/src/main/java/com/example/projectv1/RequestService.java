package com.example.projectv1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SimpleAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;


public class RequestService extends AppCompatActivity implements View.OnClickListener {

    private SharedPreferences savedValues;
    private Spinner spinner;
    private EditText et_roomNum, et_details;
    private Button btn_submit;
    private String googleID;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        if(savedValues.getBoolean("isResident",false)) {
            getMenuInflater().inflate(
                    R.menu.resident_menu, menu);
        }
        if(savedValues.getBoolean("isWorker",false)) {
            getMenuInflater().inflate(
                    R.menu.worker_menu, menu);
        }
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch (item.getItemId())
        {
            case R.id.menu_home:
                Intent intent4 = new Intent(RequestService.this, Home.class);
                startActivity(intent4);
                return true;
            case R.id.menu_request_service:
                Toast.makeText(this, "Already in Request Service",
                        Toast.LENGTH_SHORT).show();
                return true;
            case R.id.menu_requested_service:
                Intent intent3 = new Intent(RequestService.this, RequestedServices.class);
                startActivity(intent3);
                return true;
            case R.id.menu_completed_services:
                Intent intent1 = new Intent(RequestService.this, CompletedServices.class);
                startActivity(intent1);
                return true;
            case R.id.menu_accepted_services:
                Intent intent5 = new Intent(RequestService.this, AcceptedServices.class);
                startActivity(intent5);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_request_service);

        // get SharedPreferences object
        savedValues = getSharedPreferences("SavedValues", MODE_PRIVATE);
        SharedPreferences.Editor editor = savedValues.edit();

        CollectionReference requests = Login.db.collection("Requests");

        getSupportActionBar().setTitle("Request Service");

        spinner = (Spinner) findViewById(R.id.spinner);
        et_details = findViewById(R.id.et_details);
        et_roomNum = findViewById(R.id.et_roomNum);
        btn_submit = findViewById(R.id.btn_submit);

        List<String> list = new ArrayList<String>();
        list.add("Plumbing");
        list.add("Carpentry");
        list.add("Electricity");
        list.add("AC");

        ArrayAdapter<String> adapter  = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,list);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

    }

    @Override
    public void onClick(View view) {

        if (et_roomNum.getText().toString().isEmpty()){
            Toast.makeText(this, "Add room number",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        CollectionReference requests = Login.db.collection("Requests");

        // this is an ID that I am assigning to be able to extract the ID automatically made by google.
        String myID = getString();

        Map<String, Object> newRequest = new HashMap<>();
        newRequest.put("assignedWorker", "");
        newRequest.put("creator", savedValues.getString("email",""));
        newRequest.put("details", et_details.getText().toString());
        newRequest.put("isAccepted", false);
        newRequest.put("isCompleted", false);
        newRequest.put("roomNum", et_roomNum.getText().toString());
        newRequest.put("serviceType", spinner.getSelectedItem().toString());
        newRequest.put("myID", myID);
        //requests.document(savedValues.getString("email","")).set(newRequest);
        requests.add(newRequest);


        CollectionReference notifications = Login.db.collection("Notifications");

        Login.db.collection("Requests")
                .whereEqualTo("myID", myID)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Map<String, Object> noti = new HashMap<>();
                                noti.put("AcceptNotification", false);
                                noti.put("CompleteNotification",false);
                                noti.put("from", savedValues.getString("email",""));
                                noti.put("isSent",false);
                                noti.put("roomNum",et_roomNum.getText().toString());
                                noti.put("serviceType", spinner.getSelectedItem().toString());
                                noti.put("to", "workers");
                                noti.put("serviceID", document.getId());
                                notifications.add(noti);
                            }
                            }
                    }
                });

        Toast.makeText(this, "Request made successfully",Toast.LENGTH_SHORT).show();
        }

        private String getString() {

            // create a string of uppercase and lowercase characters and numbers
            String upperAlphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            String lowerAlphabet = "abcdefghijklmnopqrstuvwxyz";
            String numbers = "0123456789";

            // combine all strings
            String alphaNumeric = upperAlphabet + lowerAlphabet + numbers;

            // create random string builder
            StringBuilder sb = new StringBuilder();

            // create an object of Random class
            Random random = new Random();

            // specify length of random string
            int length = 30;

            for(int i = 0; i < length; i++) {

                // generate random index number
                int index = random.nextInt(alphaNumeric.length());

                // get character specified by index
                // from the string
                char randomChar = alphaNumeric.charAt(index);

                // append the character to string builder
                sb.append(randomChar);
            }
            return sb.toString();
            }
    }