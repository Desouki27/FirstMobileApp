package com.example.projectv1;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;
import android.view.View;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

public class MaintenanceService extends Service {

    private Timer timer;
    private SharedPreferences savedValues;
    private int NOTIFICATION_ID;

    @Override
    public void onCreate() {
        super.onCreate();
        NOTIFICATION_ID = 0;
        savedValues = getSharedPreferences("SavedValues", MODE_PRIVATE);
        SharedPreferences.Editor editor = savedValues.edit();
        startTimer();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {


        NotificationChannel serviceChannel = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            serviceChannel = new NotificationChannel(
                    "CHANNEL_ID","Foreground Service Channel",
                    NotificationManager.IMPORTANCE_DEFAULT
            );
        }
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(serviceChannel);
        }

        Intent notificationIntent = new Intent(this, Home.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this,
                0, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification notification = new NotificationCompat.Builder(
                this, "CHANNEL_ID")
                .setContentTitle("Foreground Service")
                .setContentText("Home Maintenance App is running a Foreground Service")
                .setSmallIcon(R.drawable.ic_launcher)
                .setContentIntent(pendingIntent)
                .setOngoing(true) //sticky notification
                .build();

        startForeground(1, notification);
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        stopTimer();
    }

    private void startTimer(){
        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                // code for worker notifications
                searchWorkerNotification();

                // code for resident notifications
                searchResidentNotification();

            }
        };

        // create and start timer
        timer = new Timer (true);
        int delay =0; // no delay
        int interval = 1000 * 1; // 1 second
        timer.schedule (task, delay, interval);
    }

    private void stopTimer(){
        if (timer != null) timer.cancel();
    }

    private void searchWorkerNotification(){

        if (savedValues.getBoolean("isWorker", false)) {
            //check if we need to send a new noti
            Login.db.collection("Notifications")
                    .whereEqualTo("isSent", false)
                    .whereEqualTo("to", "workers")
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                for (QueryDocumentSnapshot document : task.getResult()) {

                                    // if we're here means theres an unsent notification to workers
                                    Intent intent = new Intent(getApplicationContext(), ViewRequest.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                    intent.putExtra("ID", document.getString("serviceID"));
                                    intent.putExtra("hideAccept", false);
                                    intent.putExtra("hideComplete", true);

                                    int flags = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;
                                    PendingIntent pendingIntent =
                                            PendingIntent.getActivity(getApplicationContext(), 0, intent, flags);

                                    // getting all the variables to display in the message of the notification
                                    CharSequence roomNum = document.get("roomNum").toString();
                                    CharSequence from = document.getString("from");
                                    CharSequence serviceType = document.getString("serviceType");

                                    // create the variables for the notification
                                    int icon = R.drawable.ic_launcher;
                                    CharSequence tickerText = "New requests made";
                                    CharSequence contentTitle = "Home Maintenance App";
                                    CharSequence contentText = from + " has requested a " + serviceType + " service for room " + roomNum;

                                    NotificationChannel notificationChannel =
                                            null;
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                        notificationChannel = new NotificationChannel("Channel_ID", "My Notifications", NotificationManager.IMPORTANCE_DEFAULT);
                                    }

                                    NotificationManager manager = (NotificationManager) getSystemService(getApplicationContext().NOTIFICATION_SERVICE);
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                        manager.createNotificationChannel(notificationChannel);
                                    }

                                    // create the notification and set its data
                                    Notification notification = new NotificationCompat
                                            .Builder(getApplicationContext(), "Channel_ID")
                                            .setSmallIcon(icon)
                                            .setTicker(tickerText)
                                            .setContentTitle(contentTitle)
                                            .setContentText(contentText)
                                            .setContentIntent(pendingIntent)
                                            .setAutoCancel(true)
                                            .setChannelId("Channel_ID")
                                            .build();

                                    manager.notify(NOTIFICATION_ID++, notification);

                                    // set is sent to true
                                    Map<String, Object> request = document.getData();
                                    request.put("isSent", true);
                                    Login.db.collection("Notifications").document(document.getId()).set(request);
                                }
                            }
                        }
                    });
        }

    }
    private void searchResidentNotification(){
        if (savedValues.getBoolean("isResident", false)) {

            Login.db.collection("Notifications")
                    .whereEqualTo("isSent", false)
                    .whereEqualTo("to", savedValues.getString("email",""))
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                for (QueryDocumentSnapshot document : task.getResult()) {

                                    // if we're here means theres an unsent notification to workers
                                    Intent intent = new Intent(getApplicationContext(), ViewRequest.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                    intent.putExtra("ID", document.getString("serviceID"));
                                    intent.putExtra("hideAccept", true);
                                    intent.putExtra("hideComplete", true);

                                    int flags = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;
                                    PendingIntent pendingIntent =
                                            PendingIntent.getActivity(getApplicationContext(), 0, intent, flags);

                                    // getting all the variables to display in the message of the notification
                                    CharSequence worker = document.getString("from");
                                    Boolean AcceptNotification = document.getBoolean("AcceptNotification");
                                    Boolean CompleteNotification = document.getBoolean("CompleteNotification");
                                    CharSequence action = "accepted";
                                    if (CompleteNotification) action="completed";
                                    CharSequence serviceType = document.getString("serviceType");

                                    // create the variables for the notification
                                    int icon = R.drawable.ic_launcher;
                                    CharSequence tickerText = "Service request update";
                                    CharSequence contentTitle = "Home Maintenance App";
                                    CharSequence contentText = "Worker " + worker  + " has " + action + " your "+ serviceType + " request";

                                    NotificationChannel notificationChannel =
                                            null;
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                        notificationChannel = new NotificationChannel("Channel_ID", "My Notifications", NotificationManager.IMPORTANCE_DEFAULT);
                                    }

                                    NotificationManager manager = (NotificationManager) getSystemService(getApplicationContext().NOTIFICATION_SERVICE);
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                        manager.createNotificationChannel(notificationChannel);
                                    }

                                    // create the notification and set its data
                                    Notification notification = new NotificationCompat
                                            .Builder(getApplicationContext(), "Channel_ID")
                                            .setSmallIcon(icon)
                                            .setTicker(tickerText)
                                            .setContentTitle(contentTitle)
                                            .setContentText(contentText)
                                            .setContentIntent(pendingIntent)
                                            .setAutoCancel(true)
                                            .setChannelId("Channel_ID")
                                            .build();

                                    manager.notify(NOTIFICATION_ID++, notification);

                                    // set is sent to true
                                    Map<String, Object> request = document.getData();
                                    request.put("isSent", true);
                                    Login.db.collection("Notifications").document(document.getId()).set(request);
                                }
                            }
                        }
                    });

        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
