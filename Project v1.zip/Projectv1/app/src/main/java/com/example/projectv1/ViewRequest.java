package com.example.projectv1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;

import java.util.HashMap;
import java.util.Map;

public class ViewRequest extends AppCompatActivity implements View.OnClickListener {

    private TextView tv_vr_serviceType, tv_vr_roomNum, tv_vr_details, tv_vr_isAccepted, tv_vr_assignedWorker, tv_vr_isCompleted, tv_vr_creator;
    private Button btn_accept, btn_complete;
    private SharedPreferences savedValues;
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        if(savedValues.getBoolean("isResident",false)) {
            getMenuInflater().inflate(
                    R.menu.resident_menu, menu);
        }
        if(savedValues.getBoolean("isWorker",false)) {
            getMenuInflater().inflate(
                    R.menu.worker_menu, menu);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch (item.getItemId())
        {
            case R.id.menu_home:
                Intent intent4 = new Intent(ViewRequest.this, Home.class);
                startActivity(intent4);
                return true;
            case R.id.menu_request_service:
                Intent intent2 = new Intent(ViewRequest.this, RequestService.class);
                startActivity(intent2);
                return true;
            case R.id.menu_requested_service:
                Intent intent3 = new Intent(ViewRequest.this, RequestedServices.class);
                startActivity(intent3);
                return true;
            case R.id.menu_completed_services:
                Intent intent6 = new Intent(ViewRequest.this, CompletedServices.class);
                startActivity(intent6);
                return true;
            case R.id.menu_accepted_services:
                Intent intent5 = new Intent(ViewRequest.this, AcceptedServices.class);
                startActivity(intent5);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_request);
        getSupportActionBar().setTitle("View Request");
        savedValues = getSharedPreferences("SavedValues", MODE_PRIVATE);
        SharedPreferences.Editor editor = savedValues.edit();

        tv_vr_serviceType = (TextView) findViewById(R.id.tv_vr_serviceType);
        tv_vr_roomNum = (TextView) findViewById(R.id.tv_vr_roomNum);
        tv_vr_details = (TextView) findViewById(R.id.tv_vr_details);
        tv_vr_isAccepted = (TextView) findViewById(R.id.tv_vr_isAccepted);
        tv_vr_assignedWorker = (TextView) findViewById(R.id.tv_vr_assignedWorker);
        tv_vr_isCompleted = (TextView) findViewById(R.id.tv_vr_isCompleted);
        tv_vr_creator = (TextView) findViewById(R.id.tv_vr_creator);
        btn_accept = (Button) findViewById(R.id.btn_accept);
        btn_complete = (Button) findViewById(R.id.btn_complete);

        if (getIntent().getBooleanExtra("hideAccept",false)) btn_accept.setVisibility(View.GONE);
        if (getIntent().getBooleanExtra("hideComplete",false)) btn_complete.setVisibility(View.GONE);

        DocumentReference dr = Login.db.collection("Requests").document(getIntent().getStringExtra("ID"));
        dr.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                String assignedWorker = "None", details = "None";
                tv_vr_creator.setText(documentSnapshot.getString("creator"));
                tv_vr_isCompleted.setText(documentSnapshot.getBoolean("isCompleted").toString());
                tv_vr_isAccepted.setText(documentSnapshot.getBoolean("isAccepted").toString());
                tv_vr_serviceType.setText(documentSnapshot.getString("serviceType"));
                tv_vr_roomNum.setText(documentSnapshot.getString("roomNum"));
                if (!documentSnapshot.getString("assignedWorker").isEmpty()) assignedWorker = documentSnapshot.getString("assignedWorker");
                if (!documentSnapshot.getString("details").isEmpty()) details = documentSnapshot.getString("details");
                tv_vr_assignedWorker.setText(assignedWorker);
                tv_vr_details.setText(details);
                }
        });

        if(savedValues.getBoolean("isResident",false)) {
            btn_accept.setVisibility(View.GONE);
            btn_complete.setVisibility(View.GONE);
        }
    }

    @Override
    public void onClick(View v) {
        DocumentReference dr = Login.db.collection("Requests").document(getIntent().getStringExtra("ID"));
        if (v.getId()==R.id.btn_accept){
        dr.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                Map<String, Object> request = documentSnapshot.getData();
                request.put("assignedWorker",savedValues.getString("email",""));
                request.put("isAccepted", true);
                dr.set(request);

                CollectionReference notifications = Login.db.collection("Notifications");

                Map<String, Object> noti = new HashMap<>();
                noti.put("AcceptNotification", true);
                noti.put("CompleteNotification",false);
                noti.put("from", savedValues.getString("email",""));
                noti.put("isSent",false);
                noti.put("roomNum",documentSnapshot.get("roomNum"));
                noti.put("serviceType", documentSnapshot.get("serviceType"));
                noti.put("to", documentSnapshot.get("creator"));;
                noti.put("serviceID", dr.getId());
                notifications.add(noti);
            }
        });

        tv_vr_assignedWorker.setText(savedValues.getString("email","None"));
        tv_vr_isAccepted.setText("true");

        Toast.makeText(this, "Request Accepted",
                Toast.LENGTH_SHORT).show();
    }
    if (v.getId()==R.id.btn_complete){
        dr.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                Map<String, Object> request = documentSnapshot.getData();
                request.put("isCompleted", true);
                dr.set(request);

                CollectionReference notifications = Login.db.collection("Notifications");

                Map<String, Object> noti = new HashMap<>();
                noti.put("AcceptNotification", false);
                noti.put("CompleteNotification",true);
                noti.put("from", savedValues.getString("email",""));
                noti.put("isSent",false);
                noti.put("roomNum",documentSnapshot.get("roomNum"));
                noti.put("serviceType", documentSnapshot.get("serviceType"));
                noti.put("to", documentSnapshot.get("creator"));;
                noti.put("serviceID", dr.getId());
                notifications.add(noti);

            }
        });

        tv_vr_isCompleted.setText("true");

        Toast.makeText(this, "Request Completed",
                Toast.LENGTH_SHORT).show();
    }
}
}