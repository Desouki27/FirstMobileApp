package com.example.projectv1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;

public class CompletedServices extends AppCompatActivity implements AdapterView.OnItemClickListener {

    private SharedPreferences savedValues;

    private ListView itemsListView;
    private ArrayList<String> IDs;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        if(savedValues.getBoolean("isResident",false)) {
            getMenuInflater().inflate(
                    R.menu.resident_menu, menu);
        }
        if(savedValues.getBoolean("isWorker",false)) {
            getMenuInflater().inflate(
                    R.menu.worker_menu, menu);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch (item.getItemId())
        {
            case R.id.menu_home:
                Intent intent4 = new Intent(CompletedServices.this, Home.class);
                startActivity(intent4);
                return true;
            case R.id.menu_request_service:
                Intent intent2 = new Intent(CompletedServices.this, RequestService.class);
                startActivity(intent2);
                return true;
            case R.id.menu_requested_service:
                Intent intent3 = new Intent(CompletedServices.this, RequestedServices.class);
                startActivity(intent3);
                return true;
            case R.id.menu_completed_services:
                Toast.makeText(this, "Already in Completed Services",
                        Toast.LENGTH_SHORT).show();
                return true;
            case R.id.menu_accepted_services:
                Intent intent5 = new Intent(CompletedServices.this, AcceptedServices.class);
                startActivity(intent5);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_completed_services);

        // get SharedPreferences object
        savedValues = getSharedPreferences("SavedValues", MODE_PRIVATE);
        SharedPreferences.Editor editor = savedValues.edit();

        getSupportActionBar().setTitle("Completed Services");

        itemsListView = findViewById(R.id.itemsListView);

        itemsListView.setOnItemClickListener(this);

    }

    @Override
    protected void onResume() {
        super.onResume();

        ArrayList<HashMap<String, String>> data = new ArrayList<HashMap<String, String>>();
        IDs = new ArrayList<>();

        if(savedValues.getBoolean("isResident",false)) {

            Login.db.collection("Requests")
                    .whereEqualTo("creator", savedValues.getString("email", ""))
                    .whereEqualTo("isCompleted", true)
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                for (QueryDocumentSnapshot document : task.getResult()) {

                                    // we get all the data and add it to the arraylist which we will add to the list later
                                    HashMap<String, String> map = new HashMap<String, String>();
                                    map.put("creator", document.getString("creator"));
                                    String test = document.getString("assignedWorker");
                                    if (test.isEmpty()) test = "Unassigned";
                                    map.put("assignedWorker", test);
                                    map.put("serviceType", document.getString("serviceType"));
                                    data.add(map);
                                    IDs.add(document.getId());
                                }
                            }
                            // create the resource, from, and to variables
                            int resource = R.layout.listview_item;
                            String[] from = {"creator", "assignedWorker", "serviceType"};
                            int[] to = {R.id.tv_creator, R.id.tv_assignedWorker, R.id.tv_serviceType};
                            // create and set the adapter
                            SimpleAdapter adapter = new SimpleAdapter(getApplicationContext(), data, resource, from, to);
                            itemsListView.setAdapter(adapter);
                        }
                    });
        }
        if(savedValues.getBoolean("isWorker",false)) {
            Login.db.collection("Requests")
                    .whereEqualTo("assignedWorker", savedValues.getString("email", ""))
                    .whereEqualTo("isCompleted", true)
                    .whereEqualTo("isAccepted", true)
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                for (QueryDocumentSnapshot document : task.getResult()) {

                                    // we get all the data and add it to the arraylist which we will add to the list later
                                    HashMap<String, String> map = new HashMap<String, String>();
                                    map.put("creator", document.getString("creator"));
                                    String test = document.getString("assignedWorker");
                                    if (test.isEmpty()) test = "Unassigned";
                                    map.put("assignedWorker", test);
                                    map.put("serviceType", document.getString("serviceType"));
                                    data.add(map);
                                    IDs.add(document.getId());
                                }
                            }
                            // create the resource, from, and to variables
                            int resource = R.layout.listview_item;
                            String[] from = {"creator", "assignedWorker", "serviceType"};
                            int[] to = {R.id.tv_creator, R.id.tv_assignedWorker, R.id.tv_serviceType};
                            // create and set the adapter
                            SimpleAdapter adapter = new SimpleAdapter(getApplicationContext(), data, resource, from, to);
                            itemsListView.setAdapter(adapter);
                        }
                    });
        }
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

        Intent intent = new Intent(this, ViewRequest.class);
        intent.putExtra("ID", IDs.get(i));
        intent.putExtra("hideAccept", true);
        intent.putExtra("hideComplete", true);
        this.startActivity(intent);

    }
}