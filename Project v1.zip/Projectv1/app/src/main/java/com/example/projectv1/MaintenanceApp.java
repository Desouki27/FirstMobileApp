package com.example.projectv1;

import android.app.Application;
import android.content.Intent;
import android.util.Log;

import androidx.core.content.ContextCompat;

public class MaintenanceApp extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        ContextCompat.startForegroundService(this, new Intent(this, MaintenanceService.class));

    }
}
